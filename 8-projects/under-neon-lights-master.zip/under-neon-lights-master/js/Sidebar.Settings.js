/**
 * @author mrdoob / http://mrdoob.com/
 */

Sidebar.Settings = function ( editor ) {

	var container = new UI.Panel();
	container.setId( 'settings' );

	return container;

};
